
#include<iostream> //default
#include<conio.h> //_getch()
#include<iomanip> //formatage
#include<time.h> //randomizer // srand((unsigned)time(0)); // (rand() % 2)
#include<windows.h>
#include"functions.h"


using namespace std;

void fuckyou(string txt) {
    gotoxy(1, 11);
    cerr << setw(40) << ' ';
    gotoxy(1, 11);
    cerr << txt;
}

void main(void) {

    /*---------------------------------------------------------------------------------
    ------------------------------------ UI setup -------------------------------------
    ---------------------------------------------------------------------------------*/

    // main menu
    do {
        gotoxy(0, 0);
        cerr << "--- Welcome to my bad battle ship game ---\n\n"
            << "First, you'll have to place your boat\n"
            << "To do that, use:\n"
            << "[WASD] to move the cursor (and the boat)\n"
            << "[f] to rotate the boat\n"
            << "[space] to place the boat\n"
            << "\nPress [enter] to continue\n";
    } while (_getch() != 13);

    gotoxy(0, 2);
    for (int i(0); i < 10; i++) {
        cerr << setw(42) << " " << endl;
    }
    do {
        gotoxy(0, 2);
        cerr << "After that, you'll enter combat\n"
            << "In combat, use:\n"
            << "[WASD] to move the cursor (aim)\n"
            << "[space] to fire\n"
            << "\nPress [enter] to continue\n";
    } while (_getch() != 13);

    // header
    gotoxy(0, 0);
    cerr << setfill('-')
        << setw(12) << "B O T" << setw(8) << "-"
        << "VS"
        << setw(12) << "Y O U" << setw(8) << "-\n"
        << setfill(' ');

    // fuckyou box
    gotoxy(0, 11);
    cerr << "[" << left << setw(40) << " This is the fuckyou box " << "]"; 
    
    char replay(' ');
    while (replay == ' ') {

        int bot[10][10];//grid of the bot
        int ply[10][10];//grid of the player

        // empty grid
        gotoxy(0, 1);
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                bot[j][i] = 5;
                clear();
            }
            cerr << "  ";
            for (int j = 0; j < 10; j++) {
                ply[j][i] = 5;
                clear();
            }
            cerr << endl;
        }

        int xx(0); //cursor's X cord
        int yy(0); //cursor's Y cord
        char move(0); //player's keyboard input

        bool boatset(false); //until the boat is set
        char rota('x'); // boat's rotation
        int lenth[5] = { 5,4,3,3,2 }; //lenth of the 5 boat
        int boatid(0); //id of the current boat

        int varx(0);
        int vary(0);

        int xx2(0); 
        int yy2(0);

        int plyhp(17); //player's remaining boat sections
        int bothp(17); //bot's remaining boat sections
        int plyhealth[5] = { 5,4,3,3,2 }; //heath of the player's boat
        int bothealth[5] = { 5,4,3,3,2 }; //health of the bot's boat

        int lvl(0);
        //set difficulty
        gotoxy(0, 13);
        cerr << "Choose a difficulty: [ ]\n"
            << "[1] LOL players\n"
            << "[2] smoll brain\n"
            << "[3] big brain time\n"
            << "[4] 4 parallel universes ahead of you\n";
        while (lvl < 1 or lvl > 4) {
            gotoxy(22, 13);
            lvl = _getch() - 48;
        }
        cerr << lvl;

        //show the first boat
        gotoxy(22 + 2 * xx, 1 + yy);
        boat(); boat(); boat(); boat(); boat();

        srand((unsigned)time(0));

        /*---------------------------------------------------------------------------------
        ------------------------------------ Boat setup -----------------------------------
        ---------------------------------------------------------------------------------*/

        // player's boat setup
        fuckyou("place your boat retard");
        while (boatid < 5) {
            while (boatset == false) { //------------------ for 1 boat START

                gotoxy(22 + 2 * xx, 1 + yy);
                move = _getch();
                switch (move) {
                case'w':
                    if (yy > 0) {
                        yy--;
                    }
                    break;
                case's':
                    if (rota == 'y' and yy + lenth[boatid] < 10) {
                        yy++;
                    }
                    else if (rota == 'x' and yy < 9) {
                        yy++;
                    }
                    break;
                case'a':
                    if (xx > 0) {
                        xx--;
                    }
                    break;
                case'd':
                    if (rota == 'x' and xx + lenth[boatid] < 10) {
                        xx++;
                    }
                    else if (rota == 'y' and xx < 9) {
                        xx++;
                    }
                    break;
                case'f':
                    if (rota == 'x') {
                        rota = 'y';
                        for (yy; yy + lenth[boatid] > 10; yy--);
                        fuckyou("boat is  H I G H");
                        gotoxy(22 + 2 * xx, 1 + yy);
                    }
                    else if (rota == 'y') {
                        rota = 'x';
                        for (xx; xx + lenth[boatid] > 10; xx--);
                        fuckyou("boat is  L O N G");
                        gotoxy(22 + 2 * xx, 1 + yy);
                    }
                    break;
                case' ':
                    varx = 0;
                    vary = 0;
                    boatset = true;
                    while (varx + vary < lenth[boatid]) {
                        if (ply[xx + varx][yy + vary] != 5) {
                            boatset = false;
                            fuckyou("fuck you. cannot place here.");
                            gotoxy(22 + 2 * xx, 1 + yy);
                        }
                        if (rota == 'x') { varx++; }
                        else { vary++; }
                    }
                    break;
                }
                //display previous boat
                for (vary = 0; vary < 10; vary++) {
                    gotoxy(22, 1 + vary);
                    for (varx = 0; varx < 10; varx++) {
                        if (ply[varx][vary] == 5) {
                            clear();
                        }
                        else {
                            boat();
                        }
                    }
                }
                
                varx = 0;
                vary = 0;
                while (varx + vary < lenth[boatid]) {
                    if (boatset == true) { //add current boat is [space] is pressed
                        ply[xx + varx][yy + vary] = boatid;
                    }
                    gotoxy(22 + 2 * (xx + varx), 1 + (yy + vary)); //display current boat
                    boat();
                    if (rota == 'x') { varx++; }
                    else { vary++; }
                }
            } //------------------------------------------- for 1 boat END
            if (boatset == true) {
                fuckyou("done'd");
                gotoxy(22 + 2 * xx, 1 + yy);
                boatid++;
                boatset = false;
            }
        } // --------------- end of all player boat setup

        // bot's boat setup
        boatid = 0;
        boatset = false;
        while (boatid < 5) {
            while (boatset == false) {
                if ((rand() % 2) == 0) {
                    rota = 'x';
                    xx = (rand() % (11 - lenth[boatid]));
                    yy = (rand() % 10);
                }
                else {
                    rota = 'y';
                    xx = (rand() % 10);
                    yy = (rand() % (11 - lenth[boatid]));
                }
                
                varx = 0;
                vary = 0;
                boatset = true;
                while (varx + vary < lenth[boatid]) {
                    
                    if (bot[xx + varx][yy + vary] != 5) {
                        boatset = false;
                    }
                    if (rota == 'x') { varx++; }
                    else { vary++; }
                }

                varx = 0;
                vary = 0;
                while (boatset == true and varx + vary < lenth[boatid]) {
                    bot[xx + varx][yy + vary] = boatid;
                    if (rota == 'x') { varx++; }
                    else { vary++; }
                }
            }
            if (boatset == true) {
                boatid++;
                boatset = false;
            }
        }

        /*
        for (vary = 0; vary < 10; vary++) {
            gotoxy(22, 13 + vary);
            for (varx = 0; varx < 10; varx++) {
                cerr << ply[varx][vary] << " ";
            }
        }
        */
        /*---------------------------------------------------------------------------------
        ------------------------------------ Attack phase ---------------------------------
        ---------------------------------------------------------------------------------*/
        
        bool seek(true);
        bool moveswitch(false);

        varx = 0;
        vary = 0;

        int targetx(0);
        int targety(0);

        int fightmode(0);
        //0 = searching for a boat
        //1 = boat found, looking for orientation
        //2 = orientation found, trying to sink

        fuckyou("shoot that bitch");
        while (plyhp > 0 and bothp > 0) {

            // player's attack
            move = 0;
            while (move != ' ') {
                gotoxy(2 * xx, 1 + yy);
                move = _getch();
                switch (move) {
                case'w':
                    if (yy > 0) {
                        yy--;
                    }
                    break;
                case's':
                    if (yy < 9) {
                        yy++;
                    }
                    break;
                case'a':
                    if (xx > 0) {
                        xx--;
                    }
                    break;
                case'd':
                    if (xx < 9) {
                        xx++;
                    }
                    break;
                case' ':
                    switch (bot[xx][yy]) {
                    case 5:
                        miss();
                        bot[xx][yy] = 6;
                        fuckyou("you missed lol. just git gud.");
                        break;
                    case 6:
                        fuckyou("you already shot there retard");
                        move = 0;
                    case 7:
                        fuckyou("yo stop it! he's already dead");
                        move = 0;
                        break;
                    default:
                        bothealth[bot[xx][yy]]--;
                        if (bothealth[bot[xx][yy]] == 0) {
                            fuckyou("LET'S GO! YOU SUNK THAT BITCH!");
                        }
                        else {
                            fuckyou("was about time you get a hit");
                        }
                        gotoxy(2 * xx, 1 + yy);
                        hit();
                        bot[xx][yy] = 7;
                        bothp--;
                        break;
                    }
                    break;
                }
            }

            // bot's attack
            seek = true;
            switch (lvl) {
            case 1: //------------------------- dificulty 1
                do {
                    xx2 = (rand() % 10);
                    yy2 = (rand() % 10);
                } while (ply[xx2][yy2] > 5);
                gotoxy(22 + 2 * xx2, 1 + yy2);
                if (ply[xx2][yy2] == 5) {
                    miss();
                    ply[xx2][yy2] = 6;
                }
                else {
                    ply[xx2][yy2] = 7;
                    hit();
                    plyhp--;
                }
                break;
            
            case 2: //------------------------- dificulty 2 
            case 3: //------------------------- dificulty 3

                if (lvl == 2) { // difficulty 2
                    if (fightmode == 0) { // fight mode 0 = searching for a boat
                        varx = 0;
                        vary = 0;
                        do {
                            xx2 = (rand() % 10);
                            yy2 = (rand() % 10);
                        } while (ply[xx2][yy2] > 5);
                    }
                }
                
                if (lvl == 3) { // difficulty 3
                    if (fightmode == 0) { // fight mode 0 = searching for a boat
                        varx = 0;
                        vary = 0;
                        do {
                            xx2 = 2 * (rand() % 5);
                            yy2 = (rand() % 10);
                            if (pow(-1, yy2) < 0) {
                                xx2++;
                            }
                        } while (ply[xx2][yy2] > 5);
                    }
                }
                
                // difficulty 2 and 3
                if (fightmode == 2) { // fight mode 2 = orientation found, trying to sink
                    seek = true;
                    moveswitch = false;
                    while (seek == true) {

                        while (ply[targetx][targety] == 7) {
                            targetx = targetx + varx;
                            targety = targety + vary;
                        }

                        if (0 <= targetx and targetx <= 9 and 0 <= targety and targety <= 9) { // still in the grid

                            if (ply[targetx][targety] != 6) { // haven't shot there 
                                seek = false;

                            }
                            else if (moveswitch == false) { // already shot there
                                varx = varx * (-1);
                                vary = vary * (-1);
                                targetx = xx2 + varx;
                                targety = yy2 + vary;
                                moveswitch = true;
                            }
                            else { // already shot at both end
                                seek = false;
                                fightmode = 1;
                            }

                        }
                        else { //out of the grid

                            varx = (varx * (-1));
                            vary = (vary * (-1));
                            targetx = xx2;
                            targety = yy2;
                            moveswitch = true;
                        }
                    }
                }

                if (fightmode == 1) { // fight mode 1 = boat found, looking for orientation
                    seek = true;
                    while (seek == true) {
                        switch (rand() % 4) {
                        case 0:
                            if (yy2 - 1 >= 0 and ply[xx2][yy2 - 1] <= 5) {
                                varx = 0;
                                vary = -1;
                                seek = false;
                            }
                            break;
                        case 1:
                            if (yy2 + 1 <= 9 and ply[xx2][yy2 + 1] <= 5) {
                                varx = 0;
                                vary = 1;
                                seek = false;
                            }
                            break;
                        case 2:
                            if (xx2 - 1 >= 0 and ply[xx2 - 1][yy2] <= 5) {
                                varx = -1;
                                vary = 0;
                                seek = false;
                            }
                            break;
                        case 3:
                            if (xx2 + 1 <= 9 and ply[xx2 + 1][yy2] <= 5) {
                                varx = 1;
                                vary = 0;
                                seek = false;
                            }
                            break;
                        }
                    }
                }

                if (fightmode < 2) {
                    targetx = xx2 + varx;
                    targety = yy2 + vary;
                }
                gotoxy(22 + 2 * targetx, 1 + targety);
                if (ply[targetx][targety] == 5) {
                    miss();
                    ply[targetx][targety] = 6;
                }
                else if (ply[targetx][targety] < 5) {
                    if (fightmode < 2) {
                        fightmode++;
                    }
                    plyhealth[ply[targetx][targety]]--;
                    if (plyhealth[ply[targetx][targety]] == 0) {
                        fightmode = 0;
                    }
                    ply[targetx][targety] = 7;
                    hit();
                    plyhp--;
                }

                break;
            case 4: //------------------------- dificulty 4
                yy2 = 0;
                while (yy2 < 10 && seek == true) {
                    xx2 = 0;
                    while (xx2 < 10 && seek == true) {
                        if (ply[xx2][yy2] < 5) {
                            gotoxy(22 + 2 * xx2, 1 + yy2);
                            hit();
                            ply[xx2][yy2] = 7;
                            plyhp--;
                            seek = false;
                        }
                        xx2++;
                    }
                    yy2++;
                }
                break;
            }

        }

        if (plyhp > bothp) {
            fuckyou("What?!? You actually won? ");
        }
        else if (bothp > plyhp) {
            fuckyou("LMAO you lost to a fucking bot");
        }
        else {
            fuckyou("haha look at you barely not loosing");
        }
        gotoxy(0, 13);
        for (int i(0); i < 10; i++) {
            cerr << setw(40) << " " << endl;
        }
        gotoxy(0, 14);
        std::cout << "[space] replay\n[esc] leave\n";
        do {
            replay = _getch();
        } while (replay != 27 and replay != ' ');
        
    }
}