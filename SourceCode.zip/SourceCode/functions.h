
#pragma once
void gotoxy(int column, int line);

void clear(void);
void miss(void);
void boat(void);
void hit(void);
