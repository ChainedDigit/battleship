
#include<iostream> //default
#include<conio.h> //_getch()
#include<iomanip> //formatage
#include<time.h> //randomizer // srand((unsigned)time(0)); // (rand() % 2)
#include<stdio.h>
#include<windows.h>
#include"functions.h"

using namespace std;



void gotoxy(int column, int line) // gotoxy(0, 0);
{
    COORD coord;
    coord.X = column;
    coord.Y = line;
    SetConsoleCursorPosition(
        GetStdHandle(STD_OUTPUT_HANDLE),
        coord
    ); 
}


void clear(void) { //empty space      = 5
    cerr << "- ";
}
void boat(void) { //boat location     = 0, 1, 2, 3, 4
    cerr << "[]";
}
void miss(void) { //missed shot       = 6
    cerr << "o ";
}
void hit(void) { //boat hit by shot   = 7
    cout << "><";
}


